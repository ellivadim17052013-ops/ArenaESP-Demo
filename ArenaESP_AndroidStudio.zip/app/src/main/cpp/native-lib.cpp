#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_arena_esp_MainActivity_nativeBuildLabel(JNIEnv* env, jobject) {
    const std::string label = "Arena ESP Lab / native core ready";
    return env->NewStringUTF(label.c_str());
}
