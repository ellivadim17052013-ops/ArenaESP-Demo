package com.arena.esp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var preview: DemoView
    private var espEnabled = true
    private var lootEnabled = true
    private var distanceEnabled = true
    private var rareOnly = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 16, 24)
        window.navigationBarColor = Color.rgb(12, 16, 24)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(12, 16, 24)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(page)

        val header = TextView(this).apply {
            text = "ARENA  /  ESP LAB"
            setTextColor(Color.WHITE)
            textSize = 23f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        page.addView(header)
        page.addView(label("ANDROID DEMO • SIMULATED DATA", 11f, Color.rgb(125, 145, 170)))

        val status = TextView(this).apply {
            text = "●  DEMO MODE"
            setTextColor(Color.rgb(83, 220, 160))
            textSize = 12f
            setPadding(0, dp(16), 0, dp(14))
        }
        page.addView(status)

        preview = DemoView(this)
        page.addView(preview, LinearLayout.LayoutParams(-1, dp(270)).apply {
            bottomMargin = dp(18)
        })

        page.addView(section("VISUAL MODULES"))
        addSwitch(page, "Player ESP", "Показывать условные боксы и дистанцию", espEnabled) {
            espEnabled = it; preview.esp = it; preview.invalidate()
        }
        addSwitch(page, "Loot ESP", "Показывать условные предметы", lootEnabled) {
            lootEnabled = it; preview.loot = it; preview.invalidate()
        }
        page.addView(section("DISPLAY"))
        addSwitch(page, "Distance labels", "Подписи расстояния в метрах", distanceEnabled) {
            distanceEnabled = it; preview.distance = it; preview.invalidate()
        }
        addSwitch(page, "Rare loot only", "Скрывать обычные предметы", rareOnly) {
            rareOnly = it; preview.rareOnly = it; preview.invalidate()
        }

        page.addView(section("LOOT COLOR LEGEND"))
        page.addView(legendRow("Обычный", Color.rgb(160, 170, 185)))
        page.addView(legendRow("Редкий", Color.rgb(70, 170, 255)))
        page.addView(legendRow("Эпический", Color.rgb(190, 105, 255)))
        page.addView(legendRow("Легендарный", Color.rgb(255, 190, 65)))

        val footer = TextView(this).apply {
            text = "Это автономная демонстрация. Приложение не подключается к Arena Breakout, не читает память игры и не взаимодействует с её процессом."
            setTextColor(Color.rgb(135, 148, 168))
            textSize = 12f
            setPadding(0, dp(22), 0, dp(8))
        }
        page.addView(footer)
        setContentView(scroll)
    }

    private fun addSwitch(parent: LinearLayout, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.rgb(22, 29, 41))
        }
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textCol.addView(label(title, 15f, Color.WHITE))
        textCol.addView(label(subtitle, 11f, Color.rgb(140, 154, 176)))
        row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, value -> onChange(value) }
        }
        row.addView(toggle)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
    }

    private fun section(text: String) = label(text, 12f, Color.rgb(110, 133, 165)).apply {
        setPadding(0, dp(16), 0, dp(10))
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun legendRow(name: String, color: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val dot = View(this).apply { setBackgroundColor(color) }
        row.addView(dot, LinearLayout.LayoutParams(dp(9), dp(9)))
        row.addView(label("  $name", 13f, Color.LTGRAY))
        return row
    }

    private fun label(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

private class DemoView(context: android.content.Context) : View(context) {
    var esp = true
    var loot = true
    var distance = true
    var rareOnly = false
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 22f, 22f,
            bg.apply { color = Color.rgb(19, 27, 40) })
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = Color.rgb(45, 60, 80)
        for (x in 0..width step 38) canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), p)
        for (y in 0..height step 38) canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), p)

        p.style = Paint.Style.FILL
        p.textSize = 11f
        p.color = Color.rgb(115, 136, 162)
        canvas.drawText("SIMULATED FIELD VIEW", 16f, 23f, p)

        if (esp) {
            drawBox(canvas, width * .22f, height * .28f, Color.rgb(255, 90, 100), "PLAYER", "24m")
            drawBox(canvas, width * .62f, height * .43f, Color.rgb(255, 160, 80), "BOT", "41m")
        }
        if (loot) {
            drawLoot(canvas, width * .36f, height * .72f, Color.rgb(70, 170, 255), "Rare item")
            if (!rareOnly) drawLoot(canvas, width * .72f, height * .75f, Color.rgb(160, 170, 185), "Common item")
            drawLoot(canvas, width * .52f, height * .58f, Color.rgb(190, 105, 255), "Epic item")
        }
    }

    private fun drawBox(c: Canvas, x: Float, y: Float, color: Int, name: String, dist: String) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = color
        c.drawRect(x, y, x + 58f, y + 86f, p)
        p.style = Paint.Style.FILL; p.textSize = 12f
        c.drawText(name, x - 2f, y - 8f, p)
        if (distance) { p.textSize = 11f; c.drawText(dist, x, y + 101f, p) }
    }

    private fun drawLoot(c: Canvas, x: Float, y: Float, color: Int, name: String) {
        p.color = color; p.style = Paint.Style.FILL
        c.drawCircle(x, y, 5f, p)
        p.textSize = 10f
        c.drawText(name, x + 9f, y + 4f, p)
    }
}
